
import java.util.*;

import com.github.javaparser.ast.AccessSpecifier;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.EnumConstantDeclaration;
import com.github.javaparser.ast.body.EnumDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.ReferenceType;
import com.github.javaparser.ast.type.Type;
import com.sun.deploy.util.StringUtils;
import com.github.javaparser.ast.body.ModifierSet;

public class DetailInfo {
	
	// To extract Field details
	 public static ArrayList<String> getDetailInfo_Field(BodyDeclaration bd, ArrayList classList, ArrayList interfaceList)
	    {
	        ArrayList fieldinfo = new ArrayList();
	        FieldDeclaration field_dec = (FieldDeclaration) bd;
	        AccessSpecifier access_Specifier = ModifierSet.getAccessSpecifier(field_dec.getModifiers());  //public, private or protected

	        String onetoOne = "";
	        String onetoMany = "";
	        String type_str = field_dec.getType().toString();
	        Type field_Type = field_dec.getType();

	        if (classList.contains(type_str) || interfaceList.contains(type_str)) {
	           
	            onetoOne = type_str;
	        }
	        else {
	            if (field_Type instanceof ReferenceType) {
	                if (((ReferenceType) field_Type).getType() instanceof ClassOrInterfaceType) {
	                    List args = ((ClassOrInterfaceType) ((ReferenceType) field_Type).getType()).getTypeArgs();
	                    if (args.size() > 0) {
	                        String str = args.get(0).toString();
	                        if (classList.contains(str) || interfaceList.contains(str)) {
	                           
	                            onetoMany = str;
	                        }
	                    }
	                }
	            }
	        }
	        
	        for(VariableDeclarator var_dec: field_dec.getVariables()) {
	            String name = var_dec.getId().getName();
	            String type = field_dec.getType().toString();
	            HashMap<String, String> fieldinfo_Map = new HashMap<String, String>();
	            
	            fieldinfo_Map.put("name", name);
	            fieldinfo_Map.put("type", type);
	            
	            fieldinfo_Map.put("onetoMany", onetoMany);
	            
	            fieldinfo_Map.put("onetoOne", onetoOne);
	           
	            fieldinfo_Map.put("access_Specifier", access_Specifier.getCodeRepresenation());

	            fieldinfo.add(fieldinfo_Map);
	        }

	        return fieldinfo;
	    }
	 
	 //To extract method details
	 
	 public static HashMap getDetailInfo_Method(BodyDeclaration bd)
	    {
	        HashMap<String, String> method_details = new HashMap<String, String>();
	        MethodDeclaration md = (MethodDeclaration) bd;
	        String name = md.getName();
	        String type = md.getType().toString();
	        BlockStmt b_stmt = md.getBody();

	        if (b_stmt != null) {
	            List<Statement> method_stats = md.getBody().getStmts();
	            ArrayList newl = new ArrayList();

	            for (Statement stat: method_stats) {
	                String str = stat.toString();
	                if (str.contains("new ")) {
	                    newl.add(str.split(" ")[0]);
	                }
	            }

	            method_details.put("uses", StringUtils.join(newl, ","));
	        } else {
	        	method_details.put("uses", "");
	        }

	        ArrayList params = new ArrayList();
	        ArrayList parameter_type = new ArrayList();
	        for (Parameter para : md.getParameters()) {
	            params.add(para.toString());
	            parameter_type.add(para.getType().toString());
	        }

	        AccessSpecifier access_Specifier = ModifierSet.getAccessSpecifier(md.getModifiers());
	        method_details.put("access", access_Specifier.getCodeRepresenation());

	        method_details.put("name", name);
	        method_details.put("type", type);
	        
	       
	        method_details.put("parameters", StringUtils.join(params, ","));
	        method_details.put("parameterTypes", StringUtils.join(parameter_type, ","));

	        return method_details;

	    }
	 
	 //To extract Enumeration details
	 
	 public HashMap<String,ArrayList> getDetailInfo_Enum(BodyDeclaration bd) {
	        HashMap<String, ArrayList> enum_details = new HashMap<String, ArrayList>();
	        EnumDeclaration ed = (EnumDeclaration) bd;
	        String name = ed.getName();
	        ArrayList<String> name_list = new ArrayList<String>();
	        name_list.add(name);
	        ArrayList<String> enum_entries = new ArrayList<String>();

	        for (EnumConstantDeclaration ecd: ed.getEntries()) {
	        	enum_entries.add(ecd.getName());
	        }
	        
	        enum_details.put("enumFields", enum_entries);
	        enum_details.put("name", name_list);
	       

	        return enum_details;
	    }
	 
	 //To extract Costructor details
	 public static HashMap<String, String> getDetailInfo_Constructor(BodyDeclaration bd)
	    {
	        HashMap<String, String> constructor_details = new HashMap<String, String>();
	        ConstructorDeclaration cd = (ConstructorDeclaration) bd;
	        String name = cd.getName();

	        ArrayList params = new ArrayList();
	        ArrayList parameter_type = new ArrayList();
	        for (Parameter para : cd.getParameters()) {
	            params.add(para.toString());
	            parameter_type.add(para.getType().toString());
	        }

	        AccessSpecifier access_Specifier = ModifierSet.getAccessSpecifier(cd.getModifiers());

	        constructor_details.put("name", name);
	        constructor_details.put("access", access_Specifier.getCodeRepresenation());
	        constructor_details.put("parameters", StringUtils.join(params, ","));
	        constructor_details.put("parameterTypes", StringUtils.join(parameter_type, ","));

	        return constructor_details;

	    }


}
