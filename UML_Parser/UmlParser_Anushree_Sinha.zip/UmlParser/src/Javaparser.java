import java.io.BufferedReader;
import java.io.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.EnumDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.sun.deploy.util.StringUtils;

import net.sourceforge.plantuml.SourceStringReader;

import java.util.*;

public class Javaparser {

	public  void execute(File file, String output){
		
		try{
			
			
		Extract extract = new Extract();
		DetailInfo detailInfo = new DetailInfo();
		 ArrayList<String> javaFiles = extract.getJava_Files(file);
		 
		 
		 StringBuilder input = new StringBuilder();
		 
		 for (String jfiles : javaFiles) {
	            FileInputStream file_input = new FileInputStream(jfiles);
	            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(file_input, "UTF-8"));
	            String lines = bufferedReader.readLine();
	            while(lines != null){		//Read all the lines of the java files (A.java, B.java etc)
	                input.append(lines);
	                input.append('\n');
	                lines = bufferedReader.readLine();
	            }
	        }
		 String iStream = input.toString();
		 
		 iStream = iStream.replace("package", "// package");     //Comment out the package and import statements.
		 iStream = iStream.replace("import", "// import");
		 
		 InputStream in = new ByteArrayInputStream(iStream.getBytes(StandardCharsets.UTF_8));
			CompilationUnit compunit ; 
			TypeDeclaration td;
			try{
			compunit = JavaParser.parse(in); //compunit contains the non-commented part of the code
			}
			finally{ 
				in.close();
			}
		 
		 
		 
		 ArrayList java_classes = extract.getJavaClasses(compunit);
		 ArrayList java_interfaces = extract.getJavaInterfaces(compunit);
		 
		 ArrayList enums = extract.getEnums(compunit);
		 
		 ArrayList array1 = new ArrayList();
		 
		 for (TypeDeclaration td1 : compunit.getTypes()) {				//Each class is passed one by one (For example A.java is parsed first, then B.java and so on)
	            List<BodyDeclaration> participants = td1.getMembers();
	            
	            ArrayList interface_implemented = extract.getInterfaceImplemented(td1);
	            ArrayList extended_classes = extract.getJavaExtendClasses(td1);
	            
	            // iterate through the participants
	            if (participants != null) {
	                ArrayList field_info = new ArrayList();
	                ArrayList constructor_info = new ArrayList();
	                ArrayList method_info = new ArrayList();

	                for (BodyDeclaration bd : participants) {	//Go through each attribute one by one
	                    if (bd instanceof ConstructorDeclaration) {
	                        HashMap<String, String> constructors = detailInfo.getDetailInfo_Constructor(bd);
	                        constructor_info.add(constructors);

	                    } else if (bd instanceof MethodDeclaration) {
	                        HashMap<String, String> methods = detailInfo.getDetailInfo_Method(bd);
	                        method_info.add(methods);
	                    }
	                    else if (bd instanceof FieldDeclaration) {
	                        ArrayList<String> fields = detailInfo.getDetailInfo_Field(bd, java_classes, java_interfaces);
	                        field_info.addAll(fields);

	                    } 
	                }

	                HashMap<String, ArrayList> test = new HashMap<String, ArrayList>();
	                // for implements, extends, methods and constructors
	                test.put("implements", interface_implemented);
	                test.put("extends", extended_classes);
	                test.put("methods", method_info);
	                test.put("constructors", constructor_info);
	                
	                test.put("fields", field_info);
	                

	                ArrayList classes = new ArrayList();
	                classes.add(td1.getName());
	                test.put("name", classes);
	                array1.add(test);
	            } else if (td1 instanceof EnumDeclaration) {
	                HashMap<String, ArrayList> enum_info = detailInfo.getDetailInfo_Enum(td1);
	                array1.add(enum_info);
	            }
	        }
		 
		 String grammar = "@startuml\n";	
		 grammar = grammar + "skinparam classAttributeIconSize 0\n";
		 // for grammer
		 //Extraction from array1
		 
		 HashMap<String, ArrayList> one_Relation = new HashMap<String, ArrayList>();
		 HashMap<String, ArrayList> dep_Hash = new HashMap<String, ArrayList>();
	     HashMap<String, ArrayList> many_Relationships = new HashMap<String, ArrayList>();
	     
	        
		 for(int i=0; i<array1.size();i++){
			 HashMap<String, ArrayList> element = (HashMap<String, ArrayList>) array1.get(i);
			 ArrayList classes = element.get("name");
	            String class_name = (String) classes.get(0);

	            ArrayList fields = element.get("fields");
	            ArrayList methods = element.get("methods");
	            ArrayList constructors = element.get("constructors");
	            ArrayList extended_classes = element.get("extends");
	            ArrayList interface_implemented = element.get("implements");
	            
	            String parser_grammar = "";
	            Set<String> dependencies = new HashSet<String>();

	            Set<String> field_names = new HashSet<String>();
	            Set<String> method_names = new HashSet<String>();
	            Set<String> used_class = new HashSet<String>();
	            
	            if (enums.contains(class_name)) {
	            	grammar = grammar+ "enum " + class_name + " {\n";
	                ArrayList enum_List = element.get("enumFields");
	                for (int a = 0; a < enum_List.size(); a++) {
	                	grammar += enum_List.get(a) + "\n";
	                }
	                grammar += "}\n";
	                continue;
	            }
	            
	            for (int j = 0; j < fields.size(); j++) {
	                HashMap<String, String> field_name = (HashMap<String, String>) fields.get(j);
	                String f_name = field_name.get("name");
	                field_names.add(f_name.toLowerCase());
	            }
	            
	            //For methods
	            
	            for (int l = 0; l < methods.size(); l++) {
	                HashMap<String, String> method_map = (HashMap<String, String>) methods.get(l);
	                String name1 = method_map.get("name");
	                method_names.add(name1.toLowerCase());
	            }
	            
	            
	            // In case interface implemented contains the class name
	            if (java_interfaces.contains(class_name)) {
	                parser_grammar = "interface " + class_name + " {\n";
	            } else {
	            	parser_grammar = "class " + class_name + " {\n";
	            }
	            
	            
	            //For Constructors
	            
	            for (int k = 0; k < constructors.size(); k++) {
	                HashMap<String, String> constr = (HashMap<String, String>) constructors.get(k);
	                String const_name = constr.get("name");
	                String const_access = constr.get("access");
	                String[] const_parameters = constr.get("parameters").split(",");
	                String[] const_param_type = constr.get("parameterTypes").split(",");

	                for (int k1 = 0; k1 < const_param_type.length; k1++) {
	                    if (java_interfaces.contains(const_param_type[k1])) {
	                    	used_class.add(const_param_type[k1]);
	                    }
	                }

	                ArrayList orders = new ArrayList();

	                for (String k2: const_parameters) {
	                    if (k2.equals("")) {
	                        continue;
	                    }
	                    String[] type_name = k2.split(" ");
	                    String para_type = type_name[0];
	                    String para_name = type_name[1];
	                    orders.add(para_name + ":" + para_type);
	                }

	                String param_orders = StringUtils.join(orders, ",");

	                String sign = "+";
	                if (const_access.equals("private")) {
	                    sign = "-";
	                }
	                parser_grammar += sign + " " + const_name + "(" + param_orders + ")" + "\n";
	            }
	            
	            
	            for (int a = 0; a < methods.size(); a++) {
	                HashMap<String, String> m1 = (HashMap<String, String>) methods.get(a);
	                String m_name = m1.get("name");
	                String m_type = m1.get("type");
	                String m_access = m1.get("access");
	                String[] m_parameter_ypes = m1.get("parameterTypes").split(",");
	                String[] m_params = m1.get("parameters").split(",");
	                String[] m_uses = m1.get("uses").split(",");

	                ArrayList params_order = new ArrayList();

	                for (String q: m_params) {
	                    if (q.equals("")) {
	                        continue;
	                    }
	                    String[] para_type_name = q.split(" ");
	                    String para_type = para_type_name[0];
	                    String para_name = para_type_name[1];
	                    params_order.add(para_name + ":" + para_type);
	                    if (enums.contains(para_type)) {
	                    	grammar += class_name + " ..> " + para_type + "\n";
	                    }
	                }

	                String params_order_str = StringUtils.join(params_order, ",");

	                for (int t = 0; t < m_parameter_ypes.length; t++) {
	                    if (java_interfaces.contains(m_parameter_ypes[t])) {
	                    	used_class.add(m_parameter_ypes[t]);
	                    }
	                }

	                for (int x = 0; x < m_uses.length; x++) {
	                    if (java_interfaces.contains(m_uses[x])) {
	                    	used_class.add(m_uses[x]);
	                    }
	                }

	                if ((m_name.startsWith("get") || m_name.startsWith("set")) && m_access.equals("public") && field_names.contains(m_name.substring(3).toLowerCase())) {
	                    continue;
	                }
	                String mSign = "+";
	                if (m_access.equals("private")) {
	                    mSign = "-";
	                    continue;
	                }
	                parser_grammar += mSign + " " + m_name + "(" + params_order_str + "):" + m_type + "\n";
	            }
	            
	            
	            for (int a = 0; a < fields.size(); a++) {
	                HashMap<String, String> field_itr = (HashMap<String, String>) fields.get(a);
	                String f_name = field_itr.get("name");
	                String f_type = field_itr.get("type");
	                String f_access = field_itr.get("access_Specifier");
	                String one_to_one = field_itr.get("onetoOne");
	                String one_to_many = field_itr.get("onetoMany");
	                String f_sign = "-";
	                if (f_access.equals("public")) {
	                	f_sign = "+";
	                } else if (f_access.equals("protected")) {
	                	f_sign = "~";
//	                    continue;
	                }
	                String method_get = "get" + f_name.toLowerCase();
	                String method_set = "set" + f_name.toLowerCase();
	                if (f_access.equals("private") && (method_names.contains(method_get) || method_names.contains(method_set))) {
	                	f_sign = "-";
	                }
	                if (!f_type.startsWith("Collection<") && !f_access.equals("protected")) {
	                	parser_grammar += f_sign + " " + f_name + ":" + f_type + "\n";
	                }
	                if (java_interfaces.contains(f_type)) {
	                	used_class.add(f_type);
	                }

	                
	                if (java_classes.contains(one_to_many) || java_interfaces.contains(one_to_many)) {
	                    dependencies.add(one_to_many);
	                    if (many_Relationships.containsKey(class_name)) {
	                        ArrayList tmp = many_Relationships.get(class_name);
	                        tmp.add(one_to_many);
	                        many_Relationships.put(class_name, tmp);
	                    } else {
	                        ArrayList tmp = new ArrayList();
	                        tmp.add(one_to_many);
	                        many_Relationships.put(class_name, tmp);
	                    }
	                }
	                
	                if (java_classes.contains(one_to_one) || java_interfaces.contains(one_to_one)) {
	                    dependencies.add(one_to_one);
	                    if (one_Relation.containsKey(class_name)) {
	                        ArrayList tmp = one_Relation.get(class_name);
	                        tmp.add(one_to_one);
	                        one_Relation.put(class_name, tmp);
	                    } else {
	                        ArrayList tmp = new ArrayList();
	                        tmp.add(one_to_one);
	                        one_Relation.put(class_name, tmp);
	                    }
	                }

	            }
	            
	            parser_grammar += "}\n";
	            for (int i1 = 0; i1 < extended_classes.size(); i1++) {
	                String se = (String) extended_classes.get(i1);
	                parser_grammar += se + " <|-- " + class_name + "\n";
	            }
	            for (int k1 = 0; k1 < interface_implemented.size(); k1++) {
	                String se1 = (String) interface_implemented.get(k1);
	                parser_grammar += se1 + " <|.. " + class_name + "\n";
	            }
	            for (String s1:used_class) {
	                if (java_interfaces.contains(class_name)) {
	                    continue;
	                }
	                parser_grammar += class_name + " ..> " + s1 + "\n";
	            }

	            grammar = grammar + parser_grammar;
	           
		 }
		
		 
		 for (Map.Entry<String, ArrayList> relations : many_Relationships.entrySet()) {
	            String map_key = relations.getKey();
	            ArrayList<String> relation_value = relations.getValue();

	            for (String str_1: relation_value) {
	                if (many_Relationships.containsKey(str_1) && many_Relationships.get(str_1).contains(map_key)) {
	                    
	                	grammar += map_key + "\"*\" -- \"*\"" + str_1 + "\n";
	                } else if (one_Relation.containsKey(str_1) && one_Relation.get(str_1).contains(map_key)) {
	                    
	                    ArrayList<String> tmp = one_Relation.get(str_1);
	                    tmp.remove(map_key);
	                    one_Relation.put(str_1, tmp);
	                    grammar += map_key + "\"1\" -- \"*\"" + str_1 + "\n";
	                } else {
	                    
	                	grammar += map_key + "\"1\" -- \"*\"" + str_1 + "\n";
	                }
	            }
	        }
		 
		 
		 ArrayList<String> entered = new ArrayList<String>();
	        for (Map.Entry<String, ArrayList> entry : one_Relation.entrySet()) {
	            String keys = entry.getKey();
	            ArrayList<String> value = entry.getValue();

	            for (String c1: value) {
	                if (entered.contains(keys + "-" + c1) || entered.contains(c1 + "-" + keys)) {
	                    continue;
	                }
	                grammar += keys + "\"1\" -- \"1\"" + c1 + "\n";
	                entered.add(keys + "-" + c1);
	                entered.add(c1 + "-" + keys);
	            }
	        }
	        
	        grammar += "@enduml";

	        OutputStream jpg = null;
	        try {
	            jpg = new FileOutputStream(output);
	            SourceStringReader reader = new SourceStringReader(grammar);
	            String desc = reader.generateImage(jpg);
	        }
	        catch (FileNotFoundException e) {
	            System.out.println("File Not Found");
	        }
	        catch (IOException e) {
	            System.out.println("IO Exception");
	        }
		 
		 
	}
	
	catch (Exception ex){
		ex.printStackTrace();
	}
}
	

}


