import java.io.File;

public class Parser {

	public static void main(String[] args) throws Exception {
		
		Parser parser = new Parser();
		
		//Check for input file
		
		if(args.length == 2){
			File inputFolder = new File(args[0]);
			String output = args[1];
			
			if(inputFolder.isDirectory()){
				Javaparser jp = new Javaparser();
				jp.execute(inputFolder,output);
				
			}
			
			else{
				throw new Exception("Please enter a valid input folder");
			}
		}
		
		else{
			throw new Exception("Please enter input folder path and output file name");
			
		}
		
		
	}
}
