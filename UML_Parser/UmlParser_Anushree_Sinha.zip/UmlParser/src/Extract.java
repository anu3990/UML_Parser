import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.EnumDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.type.ClassOrInterfaceType;

public class Extract {

	public  ArrayList<String> getJava_Files(File file) {				//To extract Java Files. For example - A.java, B.java etc.
        ArrayList fileList = new ArrayList();
        for (File fileEntry : file.listFiles()) {
            String filePath = fileEntry.getPath();
            if (filePath.toLowerCase().endsWith("java")) {
                fileList.add(filePath);
            }
        }
        return fileList;
    }
	
	
	 
	 
	 public static ArrayList<String> getJavaExtendClasses(TypeDeclaration td)		//To get extended classes
	    {
	        ArrayList extend_class = new ArrayList();
	        if (td instanceof ClassOrInterfaceDeclaration) {
	            ClassOrInterfaceDeclaration cd = (ClassOrInterfaceDeclaration) td;
	            List<ClassOrInterfaceType> extendClassList = cd.getExtends();
	            for (ClassOrInterfaceType c : extendClassList) {
	            	extend_class.add(c.getName());
	            }
	        }
	        return extend_class;
	    }
	 
	 public static ArrayList<String> getJavaClasses(CompilationUnit compunit)    // To extract Java Classes
	    {
	        ArrayList classes = new ArrayList();
	        for (TypeDeclaration td : compunit.getTypes()) {
	            if(td instanceof ClassOrInterfaceDeclaration && !((ClassOrInterfaceDeclaration) td).isInterface())
	            {
	            	classes.add(td.getName());
	            }
	        }
	        return classes;
	    }
	 
	
	 
	 public static ArrayList<String> getJavaInterfaces(CompilationUnit compunit)	//To extract Java Interfaces
	    {
	        ArrayList interfaces = new ArrayList();
	        for (TypeDeclaration td : compunit.getTypes()){
	            if(td instanceof ClassOrInterfaceDeclaration && ((ClassOrInterfaceDeclaration) td).isInterface())
	            {
	            	interfaces.add(td.getName());
	            }
	        }
	        return interfaces;
	    }
	 
	 public static ArrayList<String> getInterfaceImplemented(TypeDeclaration td)	
	    {
	        ArrayList interfaces = new ArrayList();
	        if (td instanceof ClassOrInterfaceDeclaration) {
	            ClassOrInterfaceDeclaration cd = (ClassOrInterfaceDeclaration) td;
	            List<ClassOrInterfaceType> interfaceList = cd.getImplements();
	            for (ClassOrInterfaceType ci : interfaceList) {
	            	interfaces.add(ci.getName());
	            }
	        }
	        return interfaces;
	    }
	 
	 public ArrayList getEnums(CompilationUnit cu) {
	        ArrayList eList = new ArrayList();
	        for (TypeDeclaration typeDec : cu.getTypes()) {
	            if(typeDec instanceof EnumDeclaration)
	            {
	            	eList.add(typeDec.getName());
	            }
	        }
	        return eList;
	    }
	 
		public ArrayList createHashmap(CompilationUnit compunit){
			
			ArrayList Hasharray = new ArrayList<>();
			DetailInfo d_info = new DetailInfo();
			
			  for (TypeDeclaration td : compunit.getTypes()) {
		            List<BodyDeclaration> tdmembers = td.getMembers();
		            ArrayList extendedclasses = getJavaExtendClasses(td);
		            ArrayList implementInterfaces = getInterfaceImplemented(td);

		            ArrayList enumList = new ArrayList();

		            if (tdmembers != null) {
		                ArrayList fields = new ArrayList();
		                ArrayList constructors = new ArrayList();
		                ArrayList methods = new ArrayList();

		                for (BodyDeclaration member : tdmembers) {
		                    if (member instanceof FieldDeclaration) {
		                        ArrayList<String> fieldInfo = d_info.getDetailInfo_Field(member, getJavaClasses(compunit), getJavaInterfaces(compunit));
		                        fields.addAll(fieldInfo);

		                    } else if (member instanceof ConstructorDeclaration) {
		                        HashMap<String, String> constMap = d_info.getDetailInfo_Constructor(member);
		                        constructors.add(constMap);

		                    } else if (member instanceof MethodDeclaration) {
		                        HashMap<String, String> methodMap = d_info.getDetailInfo_Method(member);
		                        methods.add(methodMap);
		                    }
		                }

		                HashMap<String, ArrayList> test = new HashMap<String, ArrayList>();
		                test.put("methods", methods);
		                test.put("constructors", constructors);
		                test.put("extends", extendedclasses);
		                test.put("fields", fields);
		                test.put("implements", implementInterfaces);

		                ArrayList clsName = new ArrayList();
		                clsName.add(td.getName());
		                test.put("name", clsName);
		                Hasharray.add(test);
		            } else if (td instanceof EnumDeclaration) {
		                HashMap<String, ArrayList> enumMap = d_info.getDetailInfo_Enum(td);
		                Hasharray.add(enumMap);
		            }
		        }
			  
			  return Hasharray;
		}
}
